﻿using Microsoft.AspNetCore.Http; 
using System.ComponentModel.DataAnnotations;

namespace CSV.Models
{
    public class FileDemo
    {
        [Required(ErrorMessage = "Client Name is required")]
        public string ClientName { get; set; }

        [Required(ErrorMessage = "Vendor Name is required")]
        public string VendorName { get; set; }

        [Required(ErrorMessage = "Please select a file")]
        public IFormFile File { get; set; }
    }
}

