﻿namespace CSV.Models
{
    public class ChatbotResponse
    {
        public string ExtractedResponse { get; set; }
        public string ActualResponse { get; set; }

       public string SourceDocuments { get; set; }
    }


}
