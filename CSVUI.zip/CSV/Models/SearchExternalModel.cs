﻿namespace CSV.Models
{
    public class SearchExternalModel
    {
        public string client_name { get; set; } = string.Empty;
        public string vendor_name { get; set; } = string.Empty;
        public string query { get; set; } = string.Empty;

       public string type {  get; set; } = string.Empty;

        public string databasetype { get; set; } = string.Empty;
    }

    public class SearchApiRequestModel
    {
        public string client_name { get; set; } = string.Empty;
        public string vendor_name { get; set; } = string.Empty;
        public string query { get; set; } =  string.Empty;

        public string type { get; set; } = string.Empty;

    }

}
