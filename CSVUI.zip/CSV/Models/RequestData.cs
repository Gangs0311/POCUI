﻿namespace CSV.Models
{
    public class RequestData
    {
        public string ClientName { get; set; }
        public string VendorName { get; set; }
    }
}
