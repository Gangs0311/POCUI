﻿using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CSV.Models;

public class QueryController : Controller
{
    private readonly HttpClient _httpClient;

    public QueryController(IHttpClientFactory httpClientFactory)
    {
        _httpClient = httpClientFactory.CreateClient();
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> HandleQuery(Front queryModal)
    {
        // Process the query
        string query = queryModal.Query;
        string clientName = queryModal.ClientName;
        string vendorName = queryModal.VendorName;

        // Make a request to the external API through your backend
        var apiUrl = "http://drawbridge-pythonapp.azurewebsites.net/search";
        var response = await _httpClient.GetAsync(apiUrl);

        // Handle the response as needed
        if (response.IsSuccessStatusCode)
        {
            // Read the response content
            var result = await response.Content.ReadAsStringAsync();
            // Do something with the result
        }
        else
        {
            // Handle the error
            // For example, return an error view or message
        }

        return RedirectToAction("Index");
    }
}
