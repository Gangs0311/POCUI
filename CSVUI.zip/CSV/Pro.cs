﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;

public class CsvRecord
{
    public string SECTIONS { get; set; }
    public string CONTROL { get; set; }
    public string RESPONSE { get; set; }
    public string Answer { get; set; }
}

public class Pro
{
    public static List<CsvRecord> ReadFromCsv(string filePath)
    {
        using (var reader = new StreamReader(filePath))
        using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
        {
            var records = csv.GetRecords<CsvRecord>().ToList();
            return records;
        }
    }

    public static void WriteToCsv(string filePath, IEnumerable<CsvRecord> records)
    {
        using (var writer = new StreamWriter(filePath))
        using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
        {
            csv.WriteRecords(records);
        }
    }

    public static void Main(string[] args)
    {
        string filePath = "C:\\uploads\\Vendor Risk Assessment Database - 2023-updated.csv";
        var records = ReadFromCsv(filePath);


        for (int i = 0; i < records.Count; i++)
        {
            records[i].Answer = $"{i + 1}";
        }


        WriteToCsv(filePath, records);
    }
}